dictionary_tag = 'Gaikwad et al. 2023'

reference   = "Gaikwad, Haehnelt, Davies, Bosman, Molaro, Kulkarni, et al., subm."

url         = "https://ui.adsabs.harvard.edu/abs/2023arXiv230402038G/abstract"

description = \
"""From moderate-resolution spectra of 67 quasars at 4.85 < z < 6.05. Post-processing RT (with EX-CITE on top of the 
Sherwood simulations) is used to forward-model the Ly-a forest properties and comparing the distribution of effective
optical depths to observations."""

data_structure         = "grid" #grid or points

extracted              = True
        
ndim        = 1

dimensions_descriptors = ["redshift"]

axes        = [4.9, 5. , 5.1, 5.2, 5.3, 5.4, 5.5, 5.6, 5.7, 5.8, 5.9, 6. ]

err_left    = [0.05, 0.05, 0.05, 0.05, 0.05, 0.05, 0.05, 0.05, 0.05, 0.05, 0.05, 0.05]

err_right   = [0.05, 0.05, 0.05, 0.05, 0.05, 0.05, 0.05, 0.05, 0.05, 0.05, 0.05, 0.05]

values      = [2.534e-05, 2.267e-05, 2.668e-05, 2.758e-05, 5.100e-04, 3.533e-03, 7.246e-03, 1.630e-02, 5.596e-02, 9.364e-02, 1.282e-01, 1.744e-01]

err_up      = [5.8500e-06, 8.4000e-06, 1.3430e-05, 8.1100e-06, 8.0440e-04, 1.5084e-02, 2.7311e-02, 2.5440e-02, 7.1410e-02, 6.1820e-02, 1.2600e-01, 9.2500e-02]

err_down    = [4.440e-06, 4.490e-06, 5.530e-06, 5.550e-06, 4.036e-04, 2.457e-03, 3.506e-03, 8.340e-03, 3.362e-02, 6.391e-02, 7.360e-02, 1.089e-01]

upper_lim     = False

lower_lim     = False
